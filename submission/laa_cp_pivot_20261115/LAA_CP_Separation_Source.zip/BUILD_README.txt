Long pivot paths and short certificates for completely positive matrices
Matching editable manuscript source and exact-arithmetic companion.

Compile with Python 3.9+ and a current TeX installation:
    python build.py
The manuscript uses standard LaTeX packages, including TikZ for both vector
diagrams. Its bibliography is embedded in main.tex; no external figures or
bibliography database are needed. The corresponding PDF is supplied separately.

For the computational companion, see supplemental/README.md.
    python supplemental/code/generate_certificates.py
    python supplemental/code/verify_certificates.py
These programs use only Python's standard library. Do not run with python -O.
